/* $Id$ */

#ifndef LIBZOOKEEPER_VERSION_H
#define LIBZOOKEEPER_VERSION_H

#define LIBZOOKEEPER_MAJOR_VERSION 0
#define LIBZOOKEEPER_MINOR_VERSION 7
#define LIBZOOKEEPER_PATCH_VERSION 2

#define LIBZOOKEEPER_VERSION "0.7.2"

#endif  /* LIBZOOKEEPER_VERSION_H */

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker
 * vim<600: noet sw=4 ts=4
 */
