.. _close:

ZookeeperClient::close
========================

ZookeeperClient::close — Close the zookeeper handle and free up any resources

Description
-----------

::

    public void ZookeeperClient::close()

Parameters
----------

No arguments.

Return Values
-------------

No value is returned.
