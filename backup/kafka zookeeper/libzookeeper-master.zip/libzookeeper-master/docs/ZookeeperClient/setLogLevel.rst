.. _setLogLevel:

ZookeeperClient::setLogLevel
========================

ZookeeperClient::setLogLevel — sets the debugging level for the library

Description
-----------

::

    public static void ZookeeperClient::setLogLevel(int $logLevel)

Parameters
----------

logLevel
    Zookeeper::LOG_LEVEL_* constants.

Return Values
-------------

No value is returned.
