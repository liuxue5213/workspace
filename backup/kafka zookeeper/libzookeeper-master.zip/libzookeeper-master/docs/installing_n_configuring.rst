.. _installing_n_configuring:

Installing/Configuring
======================

Contents:

.. toctree::
    :maxdepth: 2

    requirements
    installation
    runtime_configuration
    resource_types
