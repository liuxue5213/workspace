.. _installation:

Installation
============

::

    $ phpize
    $ ./configure --with-libzookeeper=/path/to/zookeeper-c-client
    $ make
    $ make install
