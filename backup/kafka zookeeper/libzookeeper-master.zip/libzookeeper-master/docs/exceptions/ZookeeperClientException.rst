.. _ZookeeperClientException:

ZookeeperClientException
========================

Introduction
------------

Exception thrown if anything wrong occurred.

Class synopsis
--------------

::

    class ZookeeperClientException extends RuntimeException {
    }
