.. _index:

Exceptions
==========

Contents:

.. toctree::
    :maxdepth: 1

    ZookeeperClientException
    ZookeeperClientCoreException
