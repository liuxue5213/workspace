.. _requirements:

Requirements
============

This extesion requires Zookeeper C Client (https://zookeeper.apache.org/).

