# For chat demo
## start
```php server.php start``` for debug mode

```php server.php start -d``` for daemon mode

## stop
```php server.php stop```

## satus 
```php server.php status```

## restart
``` php server.php restart```

## reload
``` php server.php reload```
