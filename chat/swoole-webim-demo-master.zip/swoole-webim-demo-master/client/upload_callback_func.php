<?php
	/*
		跨域上传回调文件
	*/
	echo $_GET['data'];
	//echo '1111';