var config = {
	'domain' : "http://chat.hellosee.cc",
	'wsserver' : "ws://120.24.84.28:9501",
}